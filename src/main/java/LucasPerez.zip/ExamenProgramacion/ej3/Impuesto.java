package ExamenProgramacion.ej3;

public interface Impuesto {

    public double impuesto();

}
