package ExamenProgramacion.ej5;

public interface Remuneracion {

    double PRIMA_MAXIMA = 100.000;

    String aumentar(double cuanto);

    String disminuir(double cuanto);
}
