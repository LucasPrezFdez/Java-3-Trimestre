package ExamenProgramacion.ej5;

public interface IntegranteSeleccionFutbol {

    void concentrarse();

    void viajar();

    void entrenar();

    void jugarPartido();

}
